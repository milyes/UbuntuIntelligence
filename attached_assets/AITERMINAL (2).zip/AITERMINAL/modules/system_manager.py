def system_control():
    print("[+] Système contrôlé avec succès.")
