def connect_to_network():
    print("[+] Connexion réseau intelligente établie.")
